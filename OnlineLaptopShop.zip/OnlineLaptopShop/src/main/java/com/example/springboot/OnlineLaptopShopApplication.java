package com.example.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineLaptopShopApplication {

	public static void main(String[] args) {
		SpringApplication.run( OnlineLaptopShopApplication.class, args);
	}

}
