package com.example.springboot.model;

import java.util.HashMap;
import java.util.Map;

public class Category {
	@Entity
	@Table(name = "category_table")
	public class Category {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "category_id")
	    private long categoryId;
	    @Column(name = "name")
	    private String name;

	    @Column(name = "description")
	    private String description;
	    
	    @OneToMany(mappedBy="category",cascade=CascadeType.REMOVE)
	    @JsonIgnore
	    private List<Product> product;

	    public long getCategoryId() {
			return categoryId;
		}

		public void setCategoryId(long categoryId) {
			this.categoryId = categoryId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public List<Product> getProduct() {
			return product;
		}

		public void setProduct(List<Product> product) {
			this.product = product;
		}

		
	//liquid, tablet, capsule, drops, multivitamins, inhalers, injections
   